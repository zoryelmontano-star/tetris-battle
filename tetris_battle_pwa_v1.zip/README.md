# Tetris Battle PWA

This is a free, installable Progressive Web App prototype.

## What works now
- Playable Tetris board
- 60-second battle round
- Score + combo tracking
- Touch controls and keyboard controls
- Local best score and win count
- Random room-code generation
- Offline caching
- PWA manifest + install support

## What is intentionally not connected yet
Cross-device real-time multiplayer. The UI is already structured around rooms, but a backend is needed so 2–8 phones can share the same room and leaderboard.

A free backend option such as Firebase/Supabase can be added later.

## Run locally on a computer
From this folder:

    python -m http.server 8000

Then open:

    http://localhost:8000

## Install on a phone
A PWA must be served over HTTPS (or localhost). Deploy the folder to any free static host such as GitHub Pages, Netlify, Vercel, or Cloudflare Pages.

On iPhone:
1. Open the deployed site in Safari.
2. Tap Share.
3. Tap Add to Home Screen.

On Android:
1. Open the deployed site in Chrome.
2. Use Install app / Add to Home screen.

## Files
- index.html
- styles.css
- app.js
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png
